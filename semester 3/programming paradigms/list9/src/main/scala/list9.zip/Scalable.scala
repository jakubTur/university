trait Scalable
{
  def scale(factor: Double): Unit
}
