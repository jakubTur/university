trait Shape {
  def area(): Double
  def description(): String
}
