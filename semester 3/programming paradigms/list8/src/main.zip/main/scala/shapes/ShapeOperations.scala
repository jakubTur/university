package shapes

object ShapeOperations {
  def calculate(a: Int, b: Int): Int = {a*b}
  def calculate(a: Double, b: Double): Double = {(a*b)/2}
}
