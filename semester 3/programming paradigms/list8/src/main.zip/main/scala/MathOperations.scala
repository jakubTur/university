object MathOperations {
  def calculate(a: Int, b: Int): Int = {a+b}
}