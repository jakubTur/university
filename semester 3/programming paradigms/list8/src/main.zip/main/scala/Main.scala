import shapes.{ShapeOperations => area}
import MathOperations._
import books._
object Main {
  def main(args: Array[String]): Unit = {
    val a = area.calculate(1,2)
    val b = area.calculate(1.0, 3.0)
    val c = calculate(1,3)
    println(yearDouble(books.createData("idk","1234","john",1234)))
    val list = List[Data]
    println(a, b, c)
  }
}